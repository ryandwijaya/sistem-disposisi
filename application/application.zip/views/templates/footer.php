   
            </div>
        </div>
    </div>
</section>


<!-- Jquery Core Js --> 
<script src="<?php echo base_url() ?>assets/templates/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js ( jquery.v3.2.1, Bootstrap4 js) --> 
<script src="<?php echo base_url() ?>assets/templates/bundles/vendorscripts.bundle.js"></script> 
<script type="text/javascript" src="http://github.com/malsup/media/raw/master/jquery.media.js?v0.92"></script> 
<!-- slimscroll, waves Scripts Plugin Js -->

<script src="<?php echo base_url() ?>assets/templates/bundles/jvectormap.bundle.js"></script> <!-- JVectorMap Plugin Js -->
<script src="<?php echo base_url() ?>assets/templates/bundles/sparkline.bundle.js"></script> <!-- Sparkline Plugin Js -->
<script src="<?php echo base_url() ?>assets/templates/bundles/c3.bundle.js"></script>



<script src="<?php echo base_url() ?>assets/templates/bundles/mainscripts.bundle.js"></script>
<script src="<?php echo base_url() ?>assets/templates/js/pages/index.js"></script>
<!-- Jquery DataTable Plugin Js --> 
<script src="<?php echo base_url() ?>assets/templates/bundles/datatablescripts.bundle.js"></script>
<script src="<?php echo base_url() ?>assets/templates/js/pages/tables/jquery-datatable.js"></script>

<script>
$(function() {
var timeout = 2000; // in miliseconds (3*1000)

$('.hide-it').delay(timeout).fadeOut(200);
});

</script>
</body>


</html>