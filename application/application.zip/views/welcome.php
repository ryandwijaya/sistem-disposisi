<div class="table-responsive">
                                    <p class="text-muted font-13 m-b-30">
                                        <button class="btn btn-info">Tambah Loket</button>
                                    </p>

                                    <table id="datatable" class="table table-bordered">
                                        <thead>
                                        <tr>
                                        	<th>No</th>
                                        	<th>Loket id</th>
                                            <th>Nama Loket</th>
                                            <th>Aksi</th>
                                        </tr>
                                        </thead>


                                        <tbody>
                                        
                                        <tr>
                                            <td>1</td>
                                            <td>CS001</td>
                                            <td>Customer Service</td>
                                            <td class="text-center">
                                            	<a href="#" class="badge badge-warning">Kelola</a><br>
                                            	<a href="#" class="badge badge-danger">Hapus</a>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>